# DayatGold Smartbox - Bot AI XAU/USD (Versi Lengkap)

## Fungsi:
✅ Auto lot dari Google Sheet  
✅ Jawapan AI berdasarkan SMC  
✅ Entry harian XAU/USD  
✅ /entry ➜ lihat status modal, SL/TP, lot & catatan  

## Cara Guna:

1. Pasang keperluan:
```
pip install -r requirements.txt
```

2. Letakkan `credentials.json` dalam folder ini.

3. Jalankan bot:
```
python bot.py
```

4. Di Telegram ➜ buka @DayatGold_smartbox ➜ tekan Start ➜ taip /entry

## Nota:
- Jangan kongsi credentials.json kepada umum.
- Pastikan Google Sheet dikongsi kepada email Service Account sebagai Editor.