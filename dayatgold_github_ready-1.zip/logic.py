# logic.py

from sheets import read_today_entry

def get_entry_signal():
    data = read_today_entry()
    if not data:
        return "⚠️ Tiada data entry untuk hari ini."

    return f"""
📅 Tarikh: {data['Tarikh']}
💰 Modal: ${data['Modal']}
📈 Entry: {data['Entry']}
🎯 SL: {data['SL']} | TP: {data['TP']}
📌 Lot: {data['Lot']}
📋 Status: {data['Status']}
📝 Catatan: {data['Catatan']}
"""