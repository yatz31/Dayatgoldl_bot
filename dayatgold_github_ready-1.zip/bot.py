# bot.py

from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from config import BOT_TOKEN
from logic import get_entry_signal

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("📊 Selamat datang ke DayatGold Smartbox AI Bot!

Taip /entry untuk semak signal XAU/USD hari ini.")

async def entry(update: Update, context: ContextTypes.DEFAULT_TYPE):
    response = get_entry_signal()
    await update.message.reply_text(response)

app = ApplicationBuilder().token(BOT_TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("entry", entry))

if __name__ == "__main__":
    app.run_polling()