# bot_demo.py

from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from config import BOT_TOKEN

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("✅ Bot aktif! Selamat datang ke DayatGold Smartbox (DEMO). Taip /entry untuk semak signal demo.")

async def entry(update: Update, context: ContextTypes.DEFAULT_TYPE):
    response = """
📊 Modal: $120  
📈 Entry disarankan: BUY  
🎯 Zone OB valid di 2324.00  
🚨 SL: 2318.50 | TP: 2332.00  
💼 Lot size: 0.04
📝 Catatan: Ini contoh signal demo.
"""
    await update.message.reply_text(response)

app = ApplicationBuilder().token(BOT_TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("entry", entry))

if __name__ == "__main__":
    app.run_polling()