# sheets.py

import gspread
from oauth2client.service_account import ServiceAccountCredentials
from config import GOOGLE_SHEET_NAME, CREDENTIALS_FILE
from datetime import datetime

def read_today_entry():
    scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
    creds = ServiceAccountCredentials.from_json_keyfile_name(CREDENTIALS_FILE, scope)
    client = gspread.authorize(creds)

    sheet = client.open(GOOGLE_SHEET_NAME).sheet1
    records = sheet.get_all_records()

    today = datetime.today().strftime("%Y-%m-%d")
    for row in records:
        if str(row["Tarikh"]).strip() == today:
            return row
    return None